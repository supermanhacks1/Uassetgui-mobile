using UAssetAPI.PropertyTypes.Objects;

namespace UAssetMobile.Models;

public class AssetNode
{
    public string Name { get; set; } = string.Empty;
    public string Type { get; set; } = string.Empty;
    public string? Value { get; set; }
    public PropertyData? RawProperty { get; set; }
    public List<AssetNode> Children { get; set; } = new();
    public bool IsExpanded { get; set; }
}
