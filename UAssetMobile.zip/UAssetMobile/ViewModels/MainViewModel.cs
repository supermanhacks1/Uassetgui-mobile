using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;
using UAssetAPI;
using UAssetMobile.Models;
using UAssetMobile.Services;

namespace UAssetMobile.ViewModels;

public partial class MainViewModel : ObservableObject
{
    private readonly UAssetService _assetService;
    private readonly AssetFileService _fileService;

    [ObservableProperty]
    private bool _isAssetLoaded;

    [ObservableProperty]
    private string _statusMessage = "No asset loaded";

    [ObservableProperty]
    private EngineVersion _selectedEngineVersion = EngineVersion.VER_UE4_27;

    [ObservableProperty]
    private ObservableCollection<AssetNode> _assetNodes = new();

    [ObservableProperty]
    private AssetNode? _selectedNode;

    public MainViewModel(UAssetService assetService, AssetFileService fileService)
    {
        _assetService = assetService;
        _fileService = fileService;
    }

    [RelayCommand]
    private async Task OpenAssetAsync()
    {
        try
        {
            var filePath = await _fileService.PickAssetFileAsync();
            if (string.IsNullOrEmpty(filePath)) return;

            StatusMessage = "Loading asset...";

            await Task.Run(() => _assetService.LoadAsset(filePath, SelectedEngineVersion));

            IsAssetLoaded = true;
            StatusMessage = $"Loaded: {Path.GetFileName(filePath)}";

            // Load structure
            var nodes = await Task.Run(() => _assetService.GetAssetStructure());
            AssetNodes = new ObservableCollection<AssetNode>(nodes);
        }
        catch (Exception ex)
        {
            await Shell.Current.DisplayAlert("Error", $"Failed to load asset: {ex.Message}", "OK");
            StatusMessage = "Failed to load asset";
        }
    }

    [RelayCommand]
    private async Task ExportToJsonAsync()
    {
        if (!_assetService.IsLoaded) return;

        try
        {
            var json = await Task.Run(() => _assetService.ExportToJson());

            var filePath = Path.Combine(FileSystem.CacheDirectory, "export.json");
            await File.WriteAllTextAsync(filePath, json);

            await Share.Default.RequestAsync(new ShareFileRequest
            {
                Title = "Export JSON",
                File = new ShareFile(filePath)
            });

            StatusMessage = "Exported to JSON";
        }
        catch (Exception ex)
        {
            await Shell.Current.DisplayAlert("Error", $"Export failed: {ex.Message}", "OK");
        }
    }

    [RelayCommand]
    private async Task SaveAssetAsync()
    {
        if (!_assetService.IsLoaded) return;

        try
        {
            var bytes = await Task.Run(() => _assetService.SaveToBytes());
            await _fileService.SaveFileAsync(bytes, "modified.uasset");
            StatusMessage = "Asset saved";
        }
        catch (Exception ex)
        {
            await Shell.Current.DisplayAlert("Error", $"Save failed: {ex.Message}", "OK");
        }
    }

    [RelayCommand]
    private async Task CloseAssetAsync()
    {
        _assetService.Dispose();
        IsAssetLoaded = false;
        AssetNodes.Clear();
        StatusMessage = "No asset loaded";
    }

    [RelayCommand]
    private async Task NavigateToJsonEditorAsync()
    {
        if (!_assetService.IsLoaded)
        {
            await Shell.Current.DisplayAlert("Info", "Please load an asset first", "OK");
            return;
        }

        await Shell.Current.GoToAsync("jsoneditor");
    }

    [RelayCommand]
    private async Task ImportMappingsAsync()
    {
        var filePath = await _fileService.PickMappingsFileAsync();
        if (string.IsNullOrEmpty(filePath)) return;

        StatusMessage = "Mappings loaded";
    }
}
