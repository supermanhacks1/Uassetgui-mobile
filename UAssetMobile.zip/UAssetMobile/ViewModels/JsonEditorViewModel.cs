using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using UAssetMobile.Services;

namespace UAssetMobile.ViewModels;

public partial class JsonEditorViewModel : ObservableObject
{
    private readonly UAssetService _assetService;

    [ObservableProperty]
    private string _jsonContent = string.Empty;

    [ObservableProperty]
    private bool _isModified;

    public JsonEditorViewModel(UAssetService assetService)
    {
        _assetService = assetService;
    }

    public void LoadJson()
    {
        if (_assetService.IsLoaded)
        {
            JsonContent = _assetService.ExportToJson();
            IsModified = false;
        }
    }

    [RelayCommand]
    private async Task ImportFromJsonAsync()
    {
        try
        {
            _assetService.ImportFromJson(JsonContent);
            await Shell.Current.DisplayAlert("Success", "JSON imported successfully", "OK");
            IsModified = false;
        }
        catch (Exception ex)
        {
            await Shell.Current.DisplayAlert("Error", $"Import failed: {ex.Message}", "OK");
        }
    }

    [RelayCommand]
    private async Task SaveJsonAsync()
    {
        try
        {
            var filePath = Path.Combine(FileSystem.CacheDirectory, "edited.json");
            await File.WriteAllTextAsync(filePath, JsonContent);

            await Share.Default.RequestAsync(new ShareFileRequest
            {
                Title = "Save JSON",
                File = new ShareFile(filePath)
            });
        }
        catch (Exception ex)
        {
            await Shell.Current.DisplayAlert("Error", ex.Message, "OK");
        }
    }
}
