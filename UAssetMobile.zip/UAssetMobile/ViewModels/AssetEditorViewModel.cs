using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using UAssetMobile.Models;
using UAssetMobile.Services;

namespace UAssetMobile.ViewModels;

public partial class AssetEditorViewModel : ObservableObject
{
    private readonly UAssetService _assetService;

    [ObservableProperty]
    private AssetNode? _selectedProperty;

    [ObservableProperty]
    private string _editValue = string.Empty;

    [ObservableProperty]
    private bool _isEditing;

    public AssetEditorViewModel(UAssetService assetService)
    {
        _assetService = assetService;
    }

    [RelayCommand]
    private void SelectProperty(AssetNode node)
    {
        if (node.Type == "Export" || node.Type == "Category") return;

        SelectedProperty = node;
        EditValue = node.Value ?? string.Empty;
        IsEditing = true;
    }

    [RelayCommand]
    private async Task SavePropertyAsync()
    {
        if (SelectedProperty?.RawProperty == null) return;

        try
        {
            var prop = SelectedProperty.RawProperty;
            // Type-specific handling would go here
            await Shell.Current.DisplayAlert("Success", "Property updated (in memory)", "OK");
        }
        catch (Exception ex)
        {
            await Shell.Current.DisplayAlert("Error", ex.Message, "OK");
        }
    }

    [RelayCommand]
    private void CancelEdit()
    {
        IsEditing = false;
        SelectedProperty = null;
    }
}
