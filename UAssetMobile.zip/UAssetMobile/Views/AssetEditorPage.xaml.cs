namespace UAssetMobile.Views;

public partial class AssetEditorPage : ContentPage
{
    public AssetEditorPage(ViewModels.AssetEditorViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
