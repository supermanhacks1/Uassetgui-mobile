namespace UAssetMobile.Views;

public partial class JsonEditorPage : ContentPage
{
    private readonly ViewModels.JsonEditorViewModel _viewModel;

    public JsonEditorPage(ViewModels.JsonEditorViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
        _viewModel = viewModel;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        _viewModel.LoadJson();
    }
}
