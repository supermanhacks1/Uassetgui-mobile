using CommunityToolkit.Maui;
using UAssetMobile.Services;
using UAssetMobile.ViewModels;
using UAssetMobile.Views;

namespace UAssetMobile;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .UseMauiCommunityToolkit()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
            });

        // Register services
        builder.Services.AddSingleton<UAssetService>();
        builder.Services.AddSingleton<AssetFileService>();

        // Register ViewModels
        builder.Services.AddSingleton<MainViewModel>();
        builder.Services.AddTransient<AssetEditorViewModel>();
        builder.Services.AddTransient<JsonEditorViewModel>();

        // Register Pages
        builder.Services.AddSingleton<MainPage>();
        builder.Services.AddTransient<AssetEditorPage>();
        builder.Services.AddTransient<JsonEditorPage>();

        return builder.Build();
    }
}
