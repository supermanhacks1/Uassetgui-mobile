namespace UAssetMobile;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();

        Routing.RegisterRoute("asseteditor", typeof(Views.AssetEditorPage));
        Routing.RegisterRoute("jsoneditor", typeof(Views.JsonEditorPage));
    }
}
