namespace UAssetMobile.Services;

public class AssetFileService
{
    public async Task<string?> PickAssetFileAsync()
    {
        var result = await FilePicker.Default.PickAsync(new PickOptions
        {
            PickerTitle = "Select .uasset file",
            FileTypes = new FilePickerFileType(new Dictionary<DevicePlatform, IEnumerable<string>>
            {
                { DevicePlatform.iOS, new[] { "public.item" } },
                { DevicePlatform.Android, new[] { "application/octet-stream" } },
                { DevicePlatform.WinUI, new[] { ".uasset", ".umap" } },
                { DevicePlatform.MacCatalyst, new[] { "public.item" } }
            })
        });

        return result?.FullPath;
    }

    public async Task<string?> PickJsonFileAsync()
    {
        var result = await FilePicker.Default.PickAsync(new PickOptions
        {
            PickerTitle = "Select JSON file",
            FileTypes = new FilePickerFileType(new Dictionary<DevicePlatform, IEnumerable<string>>
            {
                { DevicePlatform.iOS, new[] { "public.json" } },
                { DevicePlatform.Android, new[] { "application/json" } },
                { DevicePlatform.WinUI, new[] { ".json" } },
                { DevicePlatform.MacCatalyst, new[] { "public.json" } }
            })
        });

        return result?.FullPath;
    }

    public async Task<string?> PickMappingsFileAsync()
    {
        var result = await FilePicker.Default.PickAsync(new PickOptions
        {
            PickerTitle = "Select .usmap mappings file",
            FileTypes = new FilePickerFileType(new Dictionary<DevicePlatform, IEnumerable<string>>
            {
                { DevicePlatform.iOS, new[] { "public.item" } },
                { DevicePlatform.Android, new[] { "application/octet-stream" } },
                { DevicePlatform.WinUI, new[] { ".usmap" } },
                { DevicePlatform.MacCatalyst, new[] { "public.item" } }
            })
        });

        return result?.FullPath;
    }

    public async Task SaveFileAsync(byte[] data, string fileName)
    {
        var filePath = Path.Combine(FileSystem.CacheDirectory, fileName);
        await File.WriteAllBytesAsync(filePath, data);

        await Share.Default.RequestAsync(new ShareFileRequest
        {
            Title = "Save UAsset file",
            File = new ShareFile(filePath)
        });
    }

    public async Task<string> ReadTextFileAsync(string filePath)
    {
        return await File.ReadAllTextAsync(filePath);
    }

    public async Task<byte[]> ReadFileBytesAsync(string filePath)
    {
        return await File.ReadAllBytesAsync(filePath);
    }
}
