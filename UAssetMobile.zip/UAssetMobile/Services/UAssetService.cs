using UAssetAPI;
using UAssetAPI.UnrealTypes;
using UAssetAPI.ExportTypes;
using UAssetAPI.PropertyTypes.Objects;

namespace UAssetMobile.Services;

public class UAssetService
{
    private UAsset? _currentAsset;
    private string? _currentFilePath;

    public UAsset? CurrentAsset => _currentAsset;
    public string? CurrentFilePath => _currentFilePath;
    public bool IsLoaded => _currentAsset != null;

    public void LoadAsset(string filePath, EngineVersion version = EngineVersion.VER_UE4_27)
    {
        _currentAsset = new UAsset(filePath, version);
        _currentFilePath = filePath;
    }

    public void LoadAsset(byte[] data, EngineVersion version = EngineVersion.VER_UE4_27)
    {
        using var ms = new MemoryStream(data);
        _currentAsset = new UAsset(ms, version);
    }

    public void SaveAsset(string? filePath = null)
    {
        if (_currentAsset == null) throw new InvalidOperationException("No asset loaded");
        _currentAsset.Write(filePath ?? _currentFilePath ?? throw new InvalidOperationException("No file path"));
    }

    public byte[] SaveToBytes()
    {
        if (_currentAsset == null) throw new InvalidOperationException("No asset loaded");
        using var ms = new MemoryStream();
        _currentAsset.Write(ms);
        return ms.ToArray();
    }

    public string ExportToJson()
    {
        if (_currentAsset == null) throw new InvalidOperationException("No asset loaded");
        return _currentAsset.SerializeJson();
    }

    public void ImportFromJson(string json)
    {
        if (_currentAsset == null) throw new InvalidOperationException("No asset loaded");
        _currentAsset.DeserializeJson(json);
    }

    public List<AssetNode> GetAssetStructure()
    {
        if (_currentAsset == null) return new List<AssetNode>();

        var nodes = new List<AssetNode>();

        // Package Info
        nodes.Add(new AssetNode
        {
            Name = "Package Info",
            Type = "Category",
            Children = new List<AssetNode>
            {
                new() { Name = $"Package Name: {_currentAsset.PackageName}", Type = "Info" },
                new() { Name = $"Engine Version: {_currentAsset.EngineVersion}", Type = "Info" },
                new() { Name = $"Legacy File Version: {_currentAsset.LegacyFileVersion}", Type = "Info" }
            }
        });

        // Name Map
        var nameMapNode = new AssetNode
        {
            Name = $"Name Map ({_currentAsset.NameMap.Count} entries)",
            Type = "Category",
            Children = _currentAsset.NameMap.Select((n, i) => new AssetNode
            {
                Name = $"[{i}] {n.Value}",
                Type = "NameMapEntry",
                Value = n.Value.Value
            }).ToList()
        };
        nodes.Add(nameMapNode);

        // Imports
        if (_currentAsset.Imports.Count > 0)
        {
            var importsNode = new AssetNode
            {
                Name = $"Imports ({_currentAsset.Imports.Count})",
                Type = "Category",
                Children = _currentAsset.Imports.Select((imp, i) => new AssetNode
                {
                    Name = $"[{i}] {imp.ObjectName}",
                    Type = "Import",
                    Value = $"Class: {imp.ClassName}, Package: {imp.ClassPackage}"
                }).ToList()
            };
            nodes.Add(importsNode);
        }

        // Exports
        if (_currentAsset.Exports.Count > 0)
        {
            var exportsNode = new AssetNode
            {
                Name = $"Exports ({_currentAsset.Exports.Count})",
                Type = "Category",
                Children = _currentAsset.Exports.Select((exp, i) => new AssetNode
                {
                    Name = $"[{i}] {exp.ObjectName}",
                    Type = "Export",
                    Children = GetExportProperties(exp)
                }).ToList()
            };
            nodes.Add(exportsNode);
        }

        return nodes;
    }

    private List<AssetNode> GetExportProperties(Export export)
    {
        var props = new List<AssetNode>();

        if (export is NormalExport normalExport)
        {
            foreach (var prop in normalExport.Data)
            {
                props.Add(new AssetNode
                {
                    Name = prop.Name.Value.ToString(),
                    Type = prop.GetType().Name,
                    Value = prop.ToString(),
                    RawProperty = prop
                });
            }
        }

        return props;
    }

    public void SetEngineVersion(EngineVersion version)
    {
        if (_currentAsset != null)
        {
            _currentAsset.EngineVersion = version;
        }
    }

    public void Dispose()
    {
        _currentAsset = null;
        _currentFilePath = null;
    }
}
